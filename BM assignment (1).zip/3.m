A(2,:) = [0 0 -exp(-l21) exp(l21) 0 0];
b(1)=0; b(2)=rl21*iapp;